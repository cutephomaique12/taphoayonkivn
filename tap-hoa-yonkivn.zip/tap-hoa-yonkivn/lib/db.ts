import { createClient } from "@supabase/supabase-js";
// Chỉ dùng ở server (API route / server component). KHÔNG import trong file "use client".
export const db = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
  auth: { persistSession: false },
});
