# Tạp Hóa YonkiVN — Next.js + Supabase + SePay

## Bảo mật (đã xử lý trong code)
- IPN xác thực bằng header `Authorization: Apikey <SEPAY_API_KEY>` (so sánh timing-safe). Ai gọi giả không có key sẽ bị 401.
- Giá lấy từ DB khi tạo đơn; client không gửi được giá.
- Giao hàng nằm trong hàm SQL `fulfill_order` (khóa dòng, `skip locked`): webhook gọi lặp hoặc 2 khách cùng mua vẫn không bán trùng acc.
- Nhận thiếu tiền thì không giao; dư tiền vẫn giao. Đơn hết kho có trạng thái `no_stock` để bạn xử lý tay.
- `SUPABASE_SERVICE_ROLE_KEY` chỉ dùng ở server, tuyệt đối không đặt tên `NEXT_PUBLIC_`.
- Mã đơn 12 ký tự ngẫu nhiên (YK + 10 hex) nên khó đoán; acc chỉ trả về khi đơn `completed`.

## Các bước
1. Cài Node.js 20+, giải nén thư mục, chạy `npm install`.
2. supabase.com > New project (Free) > SQL Editor > dán toàn bộ `supabase/schema.sql` > Run. Sửa/xóa dữ liệu mẫu ở Table Editor.
3. Nạp kho: bảng `inventory`, mỗi dòng 1 acc (`product_id`, `data` = "email|matkhau" hoặc key/link).
4. Settings > API: lấy Project URL và `service_role` key. Copy `.env.example` thành `.env.local` và điền. `SEPAY_BANK`/`SEPAY_ACC` là ngân hàng và số tài khoản đã liên kết SePay.
5. Chạy thử: `npm run dev`, mở http://localhost:3000.
6. Đẩy lên GitHub (repo mới, không commit `.env.local`), vào vercel.com > Add New Project > chọn repo > thêm toàn bộ biến trong `.env.example` ở Environment Variables > Deploy.
7. SePay > Tích hợp Webhooks > Thêm: URL `https://<tên-miền-vercel>/api/sepay-ipn`, kiểu chứng thực **API Key** = đúng giá trị `SEPAY_API_KEY`, sự kiện "có tiền vào". Nên cấu hình nhận diện mã thanh toán với tiền tố `YK`.
8. Email (tùy chọn): resend.com tạo API key, xác minh tên miền, điền `RESEND_API_KEY` và `MAIL_FROM`.
9. Test bằng đơn giá nhỏ: đặt hàng, chuyển khoản, xem màn hình tự hiện acc.
