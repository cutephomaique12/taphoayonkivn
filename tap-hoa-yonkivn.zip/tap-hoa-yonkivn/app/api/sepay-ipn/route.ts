import { timingSafeEqual } from "crypto";
import { db } from "@/lib/db";

const ok = () => Response.json({ success: true });

export async function POST(req: Request) {
  // 1) Xác thực: SePay gửi header "Authorization: Apikey <key>" (đặt cùng key trong SePay)
  const key = (req.headers.get("authorization") || "").replace(/^Apikey\s+/i, "");
  const a = Buffer.from(key), b = Buffer.from(process.env.SEPAY_API_KEY || "");
  if (!b.length || a.length !== b.length || !timingSafeEqual(a, b))
    return Response.json({ success: false }, { status: 401 });

  const p = await req.json().catch(() => null);
  if (!p || p.transferType !== "in") return ok();

  // 2) Tìm mã đơn trong nội dung chuyển khoản
  const m = String(p.code || p.content || "").toUpperCase().match(/YK[0-9A-F]{10}/);
  if (!m) return ok();

  // 3) Kiểm tra số tiền + giao hàng nguyên tử trong DB
  const { data: r } = await db.rpc("fulfill_order", {
    p_code: m[0], p_amount: Number(p.transferAmount), p_tx: String(p.id),
  });
  if (r === "ok") await sendEmail(m[0]);
  return ok(); // luôn 200 để SePay không gọi lại vô hạn; trạng thái lỗi xem trong bảng orders
}

async function sendEmail(code: string) {
  const { data: o } = await db.from("orders").select("contact,delivered").eq("code", code).single();
  if (!o || !o.contact.includes("@") || !process.env.RESEND_API_KEY) return;
  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: process.env.MAIL_FROM, to: o.contact,
      subject: `Đơn ${code}: thông tin sản phẩm của bạn`,
      text: `Cảm ơn bạn đã mua hàng!\n\nMã đơn: ${code}\n${o.delivered}`,
    }),
  }).catch(() => {});
}
