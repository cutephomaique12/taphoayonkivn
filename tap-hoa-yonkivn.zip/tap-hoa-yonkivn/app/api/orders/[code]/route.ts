import { db } from "@/lib/db";

export async function GET(_: Request, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const { data } = await db.from("orders").select("status,delivered").eq("code", code).single();
  if (!data) return Response.json({ status: "not_found" }, { status: 404 });
  // Chỉ trả thông tin acc khi đơn đã thanh toán
  return Response.json({ status: data.status, delivered: data.status === "completed" ? data.delivered : null });
}
