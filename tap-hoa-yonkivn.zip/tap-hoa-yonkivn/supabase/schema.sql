create extension if not exists pgcrypto;

create table products (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('ai','design','video','social','game')),
  name text not null, price int not null, warranty text, description text,
  active boolean default true
);
create table inventory (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references products on delete cascade,
  data text not null,                       -- "email|matkhau" hoặc key/link
  status text default 'available',          -- available | sold
  order_id uuid
);
create table orders (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                -- YK + 10 ký tự hex
  product_id uuid references products,
  amount int not null, contact text not null,
  status text default 'pending',            -- pending | completed | no_stock
  sepay_tx text unique, delivered text,
  created_at timestamptz default now()
);
alter table products enable row level security;
alter table inventory enable row level security;
alter table orders enable row level security;  -- chỉ service_role (server) truy cập

-- Giao hàng nguyên tử: chống bán trùng, chống webhook gọi lặp
create or replace function fulfill_order(p_code text, p_amount int, p_tx text)
returns text language plpgsql security definer as $$
declare o orders; inv inventory;
begin
  select * into o from orders where code = p_code for update;
  if not found then return 'not_found'; end if;
  if o.status = 'completed' then return 'done'; end if;
  if p_amount < o.amount then return 'underpaid'; end if;
  select * into inv from inventory
    where product_id = o.product_id and status = 'available'
    limit 1 for update skip locked;
  if not found then
    update orders set status='no_stock', sepay_tx=p_tx where id=o.id;
    return 'no_stock';
  end if;
  update inventory set status='sold', order_id=o.id where id=inv.id;
  update orders set status='completed', sepay_tx=p_tx, delivered=inv.data where id=o.id;
  return 'ok';
end $$;
revoke execute on function fulfill_order from public, anon, authenticated;

-- Dữ liệu mẫu (thay bằng sản phẩm thật của bạn)
insert into products (category,name,price,warranty,description) values
 ('ai','ChatGPT Plus 1 tháng',59000,'BH 30 ngày','Tài khoản cấp riêng'),
 ('design','Canva Pro 1 năm',99000,'BH 12 tháng','Nâng cấp email của bạn'),
 ('video','CapCut Pro 1 tháng',49000,'BH 30 ngày','Full tính năng'),
 ('social','Locket Gold 1 năm',89000,'BH 12 tháng','Kích hoạt trực tiếp'),
 ('game','Gói Fix Lag',29000,'BH 7 ngày','Hướng dẫn kèm theo');
